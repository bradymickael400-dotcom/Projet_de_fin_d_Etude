"""Modules applicatifs isolés."""
